CREATE DATABASE Dados_Gobuzz;
 
-- CRIANDO TABELAS USERS
CREATE TABLE Users(
	id SERIAL PRIMARY KEY, 
	nome varchar(100)
);

-- CRIANDO TABELA DE LOGIN
CREATE TABLE login_ips(
	id SERIAL PRIMARY KEY, 
	user_id int,
	created_date TIMESTAMP,
	origin_ip varchar(1),
	foreign key (user_id) references Users(id)
);

-- Inserindo dados na tabela user
INSERT INTO Users(nome) VALUES('ANNA'), ('CAETANO'), ('DANIEL');

-- Inserindo dados na tabela login
INSERT INTO login_ips (user_id, created_date, origin_ip) VALUES
    (1, '2023-01-01 12:00:00', 'G'),
    (2, '2023-01-02 14:30:00', 'A'),
    (1, '2023-01-03 10:45:00', 'G'),
    (3, '2023-01-04 08:20:00', 'G'),
    (2, '2023-01-05 18:10:00', 'B');
	
-- Esta query utiliza uma subconsulta para obter a última data de acesso para cada usuário com o IP 'G' e junta essa informação com a tabela de usuários para receber os nomes correspondentes.	
	
	SELECT u.nome
FROM Users u
JOIN (
    SELECT user_id, MAX(created_date) AS last_access_date
    FROM login_ips
    WHERE origin_ip = 'G'
    GROUP BY user_id
) AS last_access ON u.id = last_access.user_id;












